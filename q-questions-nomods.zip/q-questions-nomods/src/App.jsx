
import "./styles.css"
import "./bootstrap.css"
import ProgressBar from 'react-bootstrap/ProgressBar';


export default function App() {
  return (
    <>
    <div className="cont-return-but">
    <button className="btn return-button">Back to Modules</button>
    </div>
    <div className="cont-progress">
      <ProgressBar animated now={20} label={'20%'}></ProgressBar>
    </div>

    {/*Link the header to the respective module*/}
    <h2>Module 1: TMS Overview</h2>

    <div className="cont-question">
      <div className="cont-buttons">
      <button className="btn prev-ques">Previous Question</button>
      <button className="btn next-ques">Next Question</button>
      </div>
      <div className="cont-sep-question">
      <div className="header1-center">
        <h2>Q2</h2>
      </div>
      <div className="header-center">
        <h3>(Question)</h3>
      </div>
      <div className="question-contents">
        <div class="circle"></div>
      <hr></hr>
        <div class="circle-yellow"></div>
      <hr></hr>
        <div class="circle"></div>
      <hr></hr>
        <div class="circle"></div>
      <hr></hr>
      </div>
      </div>
    </div>
    </>
  )
}
