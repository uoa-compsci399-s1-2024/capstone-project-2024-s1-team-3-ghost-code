import "./styles.css"

export default function App() {
  return (
    <>
    <div className="cont-return-but">
      <button className="btn return-button">Back to Modules</button>
    </div>
    
    <div className="cont-quiz-feeback">
      <div className="cont-sep-question">
        <div className="header1-center">
          <h2>Q1</h2>
        </div>
        <div className="header-center">
          <h3>(Question)</h3>
        </div>
        <div className="question-contents">
          <div class="circle"></div>
          <hr></hr>
          <div class="circle-red"></div>
          <hr></hr>
          <div class="circle"></div>
          <hr></hr>
          <div class="circle"></div>
          <hr></hr>
        </div>
        </div>

    <div className="feedback-contents">

    <div className="feedback-writing">
        <h4>Detailed feedback for practice quiz</h4>
        <h4>Little feedback for final quiz</h4>
    </div>
    </div>
    
    {/*Q2*/}
    <div className="cont-sep-question">
      <div className="header1-center">
        <h2>Q2</h2>
      </div>
      <div className="header-center">
        <h3>(Question)</h3>
      </div>
      <div className="question-contents">
      <div class="circle"></div>
      <hr></hr>
      <div class="circle-red"></div>
      <hr></hr>
      <div class="circle"></div>
      <hr></hr>
      <div class="circle"></div>
      <hr></hr>
      </div>
      </div>

    <div className="feedback-contents">

    <div className="feedback-writing">
        <h4>Detailed feedback for practice quiz</h4>
        <h4>Little feedback for final quiz</h4>
    </div>
    </div>
    </div>

    <div className="side-bar">
        <div className="cont-final-score">
          <div class="circle-score">
            <div class="cont-text-circle">
            <h2 className="circle-h2">8</h2>
            <hr></hr>
            <h2 className="circle-h2">10</h2>
            </div>
            
            
            </div>
          </div>
      
    </div>
    </>
  )
}

