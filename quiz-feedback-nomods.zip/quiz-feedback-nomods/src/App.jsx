import "./styles.css"

export default function App() {
  return (
    <>
    <button className="btn return-button">Back to Modules</button>
    
    <div className="cont-quiz-feeback">
    <div className="cont-sep-question">
      <div className="header1-center">
        <br></br>
        <h2>Q1</h2>
      </div>
      <div className="header-center">
        <h3>(Question)</h3>
      </div>
      <div className="question-contents">
      <br></br>
      <div class="circle"></div>
      <hr></hr>
      <div class="circle-red"></div>
      <hr></hr>
      <div class="circle"></div>
      <hr></hr>
      <div class="circle"></div>
      <hr></hr>
      <br></br><br></br>
      </div>

    
    <div className="feedback-contents">

    <div className="feedback-writing">
        <h4>Detailed feedback for practice quiz</h4>
        <h4>Little feedback for final quiz</h4>
    </div>
    </div>
    </div>
    
    {/*Q2*/}
    <br></br>
    <br></br>
    <br></br>
    <div className="cont-sep-question">
      <div className="header1-center">
        <br></br>
        <h2>Q2</h2>
      </div>
      <div className="header-center">
        <h3>(Question)</h3>
      </div>
      <div className="question-contents">
      <br></br>
      <div class="circle"></div>
      <hr></hr>
      <div class="circle-red"></div>
      <hr></hr>
      <div class="circle"></div>
      <hr></hr>
      <div class="circle"></div>
      <hr></hr>
      <br></br><br></br>
      </div>
      </div>
    
    <div className="feedback-contents">

    <div className="feedback-writing">
        <h4>Detailed feedback for practice quiz</h4>
        <h4>Little feedback for final quiz</h4>
    </div>
    </div>
    </div>



    </>
  )
}

