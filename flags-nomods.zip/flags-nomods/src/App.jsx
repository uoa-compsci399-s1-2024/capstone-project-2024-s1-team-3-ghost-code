
import "./styles.css"
import "./bootstrap.css"
import ProgressBar from 'react-bootstrap/ProgressBar';
import Dropdown from 'react-bootstrap/Dropdown';
import DropdownButton from 'react-bootstrap/DropdownButton';


export default function App() {
  return (
    <>
    <div className="cont-nav">
    <div className="nav-bar">
      
    </div>
    </div>

    <div className="cont-overview">
    <div className="cont-return-but">
    <button className="btn return-button">Back to Modules</button>
    </div>

    {/*Link the header to the respective module*/}
    <h2>Overview</h2>

    <div className="cont-overview-module">
      <h2>Module 1</h2>
      <ul></ul>
      First attempt passing amount: 30%
      <br></br>
      Second attempt passing amount: 60%
      <br></br>
      Average attempts taken to pass: 3
    </div>


    <div className="sort-by">

     {/*
    <Dropdown>
      <Dropdown.Toggle variant="success" id="dropdown-basic">
        Sort By:
      </Dropdown.Toggle>

      <Dropdown.Menu>
        <Dropdown.Item href="#/action-1">Flags</Dropdown.Item>
        <Dropdown.Item href="#/action-2">Ascending</Dropdown.Item>
        <Dropdown.Item href="#/action-3">Descending</Dropdown.Item>
      </Dropdown.Menu>
    </Dropdown>
    */}


      </div>
      <div className="flags">

      <div className="dropdown">
      <span>Sort by:</span>
      <div className="dropdown-content">
        <p>Ascending</p>
        <p>Descending</p>
      </div>
    </div>

        <h3>Flags:</h3>
        <div className="cont-overview-qs">
          <div className="cont-overview-sep-qs">
            <h4>Question example text</h4>
            Accuracy: 30%
          </div>
          <div className="cont-overview-sep-qs">
            <h4>Question example text</h4>
            Accuracy: 32%
          </div>
          <div className="cont-overview-sep-qs">
            <h4>Question example text</h4>
            Accuracy: 46%
          </div>
          <div className="cont-overview-sep-qs">
            <h4>Question example text</h4>
            Accuracy: 58%
          </div>
        </div>


      </div>
    </div>


    </>
  )
}
